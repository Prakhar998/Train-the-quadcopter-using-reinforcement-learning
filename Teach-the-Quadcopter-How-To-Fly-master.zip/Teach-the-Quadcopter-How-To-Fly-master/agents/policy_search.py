Jupyter Notebook
policy_search.py
03/09/2018
Python
File
Edit
View
Language

1
import numpy as np
2
from task import Task
3
​
4
class PolicySearch_Agent():
5
    def __init__(self, task):
6
        # Task (environment) information
7
        self.task = task
8
        self.state_size = task.state_size
9
        self.action_size = task.action_size
10
        self.action_low = task.action_low
11
        self.action_high = task.action_high
12
        self.action_range = self.action_high - self.action_low
13
​
14
        self.w = np.random.normal(
15
            size=(self.state_size, self.action_size),  # weights for simple linear policy: state_space x action_space
16
            scale=(self.action_range / (2 * self.state_size))) # start producing actions in a decent range
17
​
18
        # Score tracker and learning parameters
19
        self.best_w = None
20
        self.best_score = -np.inf
21
        self.noise_scale = 0.1
22
​
23
        # Episode variables
24
        self.reset_episode()
25
​
26
    def reset_episode(self):
27
        self.total_reward = 0.0
28
        self.count = 0
29
        state = self.task.reset()
30
        return state
31
​
32
    def step(self, reward, done):
33
        # Save experience / reward
34
        self.total_reward += reward
35
        self.count += 1
