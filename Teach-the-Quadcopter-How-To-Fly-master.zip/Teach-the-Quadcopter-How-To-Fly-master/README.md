# Teach-the-Quadcopter-How-To-Fly

In this project, we will design an agent to fly a quadcopter, and then train it using a reinforcement learning algorithm of your choice!

# Getting Started

## Prerequisites

you much know the basics of the reinforcement learning principles to be able to go deep in this project

## Project Instructions and Installation

you can check [this](https://github.com/udacity/RL-Quadcopter-2) to go to the main repository about this project from Udacity to get more details about this project.


